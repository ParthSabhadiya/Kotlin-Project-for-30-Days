package com.antonioleiva.bandhookkotlin.di.qualifier

import javax.inject.Qualifier

@Qualifier
annotation class CacheDuration