package com.antonioleiva.bandhookkotlin.di.scope

import javax.inject.Scope

@Scope
annotation class ActivityScope
